# -*- coding: utf-8 -*-


class DuplicateMessageException(Exception):
    pass
