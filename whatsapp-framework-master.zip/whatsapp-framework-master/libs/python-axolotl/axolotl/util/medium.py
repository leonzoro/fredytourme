# -*- coding: utf-8 -*-


class Medium:
    MAX_VALUE = 0xFFFFFF
