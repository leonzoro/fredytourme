# -*- coding: utf-8 -*-


class NoSessionException(Exception):
    pass
