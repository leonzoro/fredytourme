# -*- coding: utf-8 -*-


class LegacyMessageException(Exception):
    pass
