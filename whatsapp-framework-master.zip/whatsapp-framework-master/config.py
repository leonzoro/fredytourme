credentials = dict(
    phone = 'YOUR_PHONE',
    password = 'YOUR_PASWWORD',
)

# Your contacts numbers (Framework will sync)
# Add them here
contacts = {
    "CONTACT_PHONE": "CONTACT_NAME",
    "ANOTHER_CONTACT_PHONE": "ANOTHER_CONTACT_NAME",
}